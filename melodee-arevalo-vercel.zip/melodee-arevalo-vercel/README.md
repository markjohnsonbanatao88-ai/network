# Melodee Arevalo Chat Viewer

Static Vercel-ready chat archive generated from the uploaded CSV.

## Files
- `index.html` — readable chat viewer with embedded message data
- `vercel.json` — static Vercel config
- `package.json` — optional deploy script

## Deploy with Vercel CLI

```bash
npm i -g vercel
cd melodee-arevalo-vercel
vercel --prod
```

## Privacy note

This static site contains the chat data inside `index.html`. Any deployed Vercel URL may be public unless you enable access protection or keep the URL private.
